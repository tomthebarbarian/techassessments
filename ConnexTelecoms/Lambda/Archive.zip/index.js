import getProvince from "./getProvince.js";
console.log(getProvince());