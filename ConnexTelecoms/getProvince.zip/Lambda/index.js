import getProvince from "./getProvince.js";
getProvince();